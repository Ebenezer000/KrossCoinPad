import React, { Component } from 'react';

export default class ContentWrapper extends Component{

    render(){
        return(
            <>
            <main className="layout__content">
                {this.props.children}
            </main>
            </>
        )
    }
}