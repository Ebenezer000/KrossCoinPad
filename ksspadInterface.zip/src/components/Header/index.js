import React, { useState } from 'react'
import styled from 'styled-components'
import { Link } from 'react-router-dom'
// import LOGO from '../../assets/afi_logo.png';
import BNB_LOGO from '../../assets/bnb_logo.svg';
import { useTranslation } from 'react-i18next'
import { Text } from 'rebass'
import { ALLOWED_CHAIN, CHAIN } from '../../constants';
import KSS_ABI from '../../constants/abis/BEP20.json';
import { ethers } from 'ethers';
import { useEffect } from 'react';
import { isMobile } from 'react-device-detect';
import infoIcon from '../../assets/icons/info.svg';

const BalanceText = styled(Text)`

`

const NetworkCard = styled.div`
  border-radius: 12px;
  padding: 8px 12px;
`

export default function Header({enableWallet, address, bnbBalance, chain, provider, network, disconnect }) {
    const { t } = useTranslation()

    const [kssbalance, setKssBalance] = useState('0')

    const getKSSBalance = async (addr) => {
      const contract = new ethers.Contract('0xa1f0EFd80793f97EDC74F58C0Cef93F3A1b72a79', KSS_ABI, provider);
      try {
          if(contract.provider !== null){
              const bal = await contract.balanceOf(addr);
              return parseFloat(ethers.utils.formatEther(bal));
          }
      } catch (error) {
          console.log(error);
      }
    }

    const bscData = async (addr) =>{
      const kssbalance = await getKSSBalance(addr);
      setKssBalance(kssbalance);
    }

    useEffect(() => {
        document.title = `KSSPAD | ${kssbalance} KSS`;
    }, [setKssBalance])

    useEffect(() => {
        const fetchData = async () =>{
            bscData(address);
        }
        fetchData();
    }, [address])

    return(
            <header className="layout__header">
              <div className="header" data-component="Spoiler">
                <div className="header__inner">
                  <div className="grid _space-tiny _items-center">
                    <div className="grid__el">
                      <Link to="/" className="header__logo">
                        KSS<span className="font-weight-bold">PAD</span>
                      </Link>
                    </div>
                    <div className="grid__el _size-auto">
                      <Link to="wallet" className="header__link">
                        <img src={infoIcon} />
                      </Link>
                    </div>
                    <div className="grid__el _size-auto hidden-xs-down">
                      <Link to="/kyc" className="button _color-primary _size-small">
                        KYC
                      </Link>
                    </div>
                    <div className="grid__el _size-auto hidden-xs-down">
                    {address && bnbBalance ? (
                          <BalanceText style={{ flexShrink: 0 }} pl="0.75rem" pr="0.5rem" fontWeight={500}>
                              <img width={'15px'} src={BNB_LOGO} alt="logo" /> {bnbBalance} BNB | {kssbalance || 0} KSS
                          </BalanceText>
                      ) :
                          <>
                            {
                              isMobile ? <a href="https://link.trustwallet.com/open_url?coin_id=56&url=https://ksspad.com/" className="button _size-small _color-primary">
                                Open In TrustWallet
                              </a> :
                              <button onClick={enableWallet} className="button _size-small _color-primary">
                                Connect Wallet
                            </button>
                            }
                          </>
                    }
                    </div>
                    {
                      address && bnbBalance && chain === ALLOWED_CHAIN && (
                          <div className="grid__el _size-auto hidden-xs-down">
                            <Link to="#" onClick={disconnect}>
                              disconnect
                            </Link>
                          </div>)

                    }
                    <div className="grid__el _size-auto hidden-xs-down">
                      <Link to="projects" className="button _size-small">
                        Projects
                      </Link>
                    </div>
                    <div className="grid__el _size-auto hidden-sm-up">
                      {address && bnbBalance ? (
                          <BalanceText style={{ flexShrink: 0 }} pl="0.75rem" pr="0.5rem" fontWeight={500}>
                              <img width={'15px'} src={BNB_LOGO} alt="logo" /> {bnbBalance} BNB | {kssbalance || 0} KSS
                          </BalanceText>
                      ) :
                        <>
                        {
                          isMobile ?
                            !window.ethereum ? <a className="button _size-small _color-primary" href="https://link.trustwallet.com/open_url?coin_id=56&url=https://ksspad.com/">
                            Open In TrustWallet
                          </a> :
                          <button onClick={enableWallet} className="button _size-small _color-primary">
                            Connect Wallet
                        </button>
                        : <button onClick={enableWallet} className="button _size-small _color-primary">
                            Connect Wallet
                        </button>
                        }
                      </>
                      }
                    </div>
                  </div>
                 </div>
              </div>
            </header>

    )

}