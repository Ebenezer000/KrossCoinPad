import alertifyjs from 'alertifyjs';

export const alertifyPrompt = (body) => {
    return alertifyjs.alert()
            .setting({
                'label': 'Ok',
                'frameless': true,
                'closable': false,
                'message': body,
            }).show();
}

export const alertifyCloseAllPrompt = () => {
    return alertifyjs.alert().close();

}