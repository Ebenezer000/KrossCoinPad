import React from 'react'
import { Link } from 'react-router-dom';
import telegram_logo from '../../assets/icons/telegram.svg';
import twitter_logo from '../../assets/icons/twitter.svg';
import insta_logo from '../../assets/icons/instagram.svg';

export default function Footer() {
    return (
        <footer className="layout__footer">
            <div className="footer">
                <div className="footer__inner">
                    <div className="grid _space-small">
                    <div className="grid__el _size-12 _md-size-fluid">
                        <Link to="/" className="footer__logo">
                            KSS<span className="font-weight-bold">PAD</span>
                        </Link>
                    </div>
                    <div className="grid__el _size-auto">
                        <div className="footer__socials">
                            <div className="footer__social">
                                <a href="https://t.me/ksspad" className="footer__social-link" target="_blank">
                                    <img src={telegram_logo} className="footer__social-icon"/>
                                </a>
                            </div>
                            <div className="footer__social">
                                <a href="https://Twitter.com/krosscoin_team" className="footer__social-link" target="_blank">
                                    <img src={twitter_logo} className="footer__social-icon"/>
                                </a>
                            </div>
                            <div className="footer__social">
                                <a href="https://instagram.com/Krosscoin" className="footer__social-link" target="_blank">
                                    <img src={insta_logo} className="footer__social-icon"/>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div className="grid__el _size-12">
                        <div className="grid _space-tiny">
                        <div className="grid__el _size-12 _sm-size-fluid">
                            <div className="footer__text">
                                © Vinekross LLC, 2021
                            </div>
                        </div>
                        <div className="grid__el _size-auto">
                            <Link to="privacy-policy" className="footer__text footer__link">
                            Privacy Policy
                            </Link>
                        </div>
                        <div className="grid__el _size-auto">
                            <Link to="terms-of-use" className="footer__text footer__link">
                            Terms of Use
                            </Link>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
        </footer>
    )
}

