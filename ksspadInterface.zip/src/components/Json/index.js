import React from 'react';
import common from '../../data/common.json';

export function Plans() {

    const res = common.plans.map((item, index) => {
        return (
            <div className="grid__el _size-12 _sm-size-6 _lg-size-4" key={index}>
                <div className="plan">
                    <div className="plan__name" style={{ color: item.color }}>{ item.name }</div>
                    <div className="plan__benefits">
                        {
                            item.benefits.map((item2, index2) => {
                                return (
                                    <div className="plan__benefit" key={index2}>
                                        <div className="plan__benefit-label">{ item2.label }</div>
                                        <div className="plan__benefit-value">{ item2.value }</div>
                                    </div>
                                )
                            })
                        }
                    </div>
                    <div className="plan__footer">
                    <a href="https://link.medium.com/5HR3fUvbtfb" className="button _size-small _color-primary _width-full" target="_blank">
                        Learn more
                    </a>
                    </div>
                </div>
            </div>)
    })

    return res;
}



import { Link } from 'react-router-dom';


export function SoonProjects() {

    const res = common.soonProjects.map((item, index) => {
        return (
        <div className="grid__el _filled _size-12 _md-size-6 carousel__item" key={index} data-component-ref="Carousel:item">
            <div className="project">
                <div className="project__main">
                <div className="project__image">
                    <div style={{width: '85px', height: '85px', background: '#ccc'}}></div>
                </div>
                <div className="project__content">
                    <div className="project__content-header">
                    <div className="project__content-main">
                        <div className="project__name">{ item.name }</div>
                        <div className="project__socials">
                        {
                            item.socials.map((item2, index2) => {
                                const icon_logo =  `${process.env.PUBLIC_URL}/${item2.icon}`;

                                console.log(icon_logo)
                                return (
                                    <div className="project__social" key={index2}>
                                        <Link to={ item2.url } className="project__social-link">

                                            <img src={item2.icon} className="project__social-icon"/>
                                        </Link>
                                        </div>
                                )
                            })
                        }
                        </div>
                    </div>
                    <div className="project__content-labels">
                        <div className="project__content-label _status">{ item.status.label }</div>
                        <div className="project__content-label ">USDT</div>
                    </div>
                    </div>
                    <div className="project__description">{ item.description }</div>
                    <a href={ item.url } className="project__link">Learn more</a>
                </div>
                </div>
                <div className="project__footer">
                <div className="project__params">
                    <div className="project__param">
                    <div className="project__param-label">Swap Rate</div>
                    <div className="project__param-value">{ item.swapRate }</div>
                    </div>
                    <div className="project__param">
                    <div className="project__param-label">Cap</div>
                    <div className="project__param-value">{ item.cap }</div>
                    </div>
                    <div className="project__param">
                    <div className="project__param-label">Access</div>
                    <div className="project__param-value">{ item.access }</div>
                    </div>
                </div>
                <div className="grid">
                    <div className="grid__el project__text">
                        Progress
                    </div>
                </div>
                <div className="project__progress">
                    <div className="project__progress-line" style={{width: item.progress}}></div>
                    </div>
                    <div className="project__text _big">
                        { item.progress }.00%
                    </div>
                </div>
            </div>
        </div>)
    })

    return res;
}

export function OpenProjects() {

    const res = common.openProjects2.map((item, index) => {
        return (
        <div className="grid__el _size-12" data-component-ref="Carousel:item" key={index}>
            <div className="project-card">
                <div className="project-card__main">
                <div className="project-card__image">
                    <div style={{width: '175px', height: '175px', background: '#ccc'}}></div>
                </div>
                <div className="project-card__content">
                    <div className="project-card__content-header">
                    <div className="project-card__content-main">
                        <div className="project-card__name">{ item.name }</div>
                        <div className="project-card__socials">
                        {
                            item.socials.map((item2, index2) => {
                                return (
                                    <div className="project-card__social" key={index2}>
                                        <a href={ item2.url } className="project-card__social-link">
                                            <img src={ item2.icon } className="project-card__social-icon" />
                                        </a>
                                    </div>
                                )
                            })
                        }
                        </div>
                    </div>
                    <div className="project-card__content-labels">
                        <div className="project-card__content-label _status ">{ item.status.label }</div>
                        <div className="project-card__content-label ">USDT</div>
                    </div>
                    </div>
                    <div className="project-card__description">{ item.description }</div>
                    <a href={ item.url } className="project-card__link">Learn more</a>
                </div>
                </div>
                <div className="project-card__buttons">
                <div className="grid _space-v-mini">
                    <div className="grid__el _size-12 _sm-size-6">
                    <button type="button" className="button _size-small _circled _color-secondary _inverted _width-full">
                        Approve
                    </button>
                    </div>
                    <div className="grid__el _size-12 _sm-size-6">
                    <button type="button" className="button _size-small _circled _color-secondary _width-full">
                        Join Pool
                    </button>
                    </div>
                </div>
                </div>
                <div className="project-card__params">
                {
                    item.params.map((item2, index2) => {
                        return (
                            <div className="project-card__param" key={index2}>
                            <div className="project-card__param-label">{ item2.label }</div>
                            <div className="project-card__param-value">{ item2.value }</div>
                            </div>
                        )
                    })
                }
                </div>
            </div>
        </div>
        )
    })

    return res;
}
