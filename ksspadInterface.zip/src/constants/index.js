export const ethereum = window.ethereum;
export const session = window.sessionStorage;

export const INFURA_ID = '75af53fddc6c46179d807aa4287b89d1';
export const ALLOWED_CHAIN = 56;

export const CHAIN = {
    1: 'Ethereum',
    3: 'Ropsten',
    4: 'Rinkeby',
    5: 'Goerli',
    42: 'Kovan',
    56: 'Binance Smart Chain ',
    97: 'BSC-TESTNET ',
}

export const BSCSCAN_ADDRESS = 'https://bscscan.com/address/';

