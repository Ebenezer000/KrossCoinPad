import { alertifyCloseAllPrompt, alertifyPrompt } from "../components/AlertifyPrompt";
import { ALLOWED_CHAIN, CHAIN } from "../constants";


export const verifyChain = (chainId) =>{
    if(chainId !== ALLOWED_CHAIN && CHAIN[chainId] !== undefined){
        alertifyPrompt(
            `<div style="color: #000000;" class="my-2">
                <strong>
                    <center>Switch to the ${CHAIN[ALLOWED_CHAIN]} network</center>
                </strong>
            </div>
            <div style="color: #000000; text-align: center;" class="mt-4">
                <div>You’re currently on ${CHAIN[chainId]} network.</div>
                <div>Waiting for the right network...</div>
                <div class="small">Switch networks from your wallet</div>
            </div>`
        );
        return;
    }
    alertifyCloseAllPrompt();
    return;
}