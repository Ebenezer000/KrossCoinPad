import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter } from "react-router-dom";
import App from "./App";

import "bootstrap/dist/css/bootstrap.min.css";
import "alertifyjs/build/css/alertify.css";
import './assets/styles/app.css';

ReactDOM.render(
    <BrowserRouter>
            <App />
    </BrowserRouter>,
  document.getElementById("root")
);