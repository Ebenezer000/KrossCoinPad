import React, {useEffect, useState} from 'react';
import parners_logo from '../../assets/images/partner.svg';
import parners2_logo from '../../assets/images/partner-2.svg';
import parners3_logo from '../../assets/images/partner-3.png';
import advisor_logo from  '../../assets/images/advisors/Ian Chew.jpeg'
import advisor_logo2 from  '../../assets/images/advisors/Japhet Lim.jpg'
import advisor_logo3 from  '../../assets/images/advisors/Nicholas Soong.JPG'
import linkedin_logo from  '../../assets/icons/linkedin.png'
import hero_logo from '../../assets/images/hero.png';
import about_logo from '../../assets/images/about.png';
import circle_logo from '../../assets/images/circle.png';
import cover_logo from '../../assets/images/cover.png';
// import projects_logo from '../../assets/images/projects-hero.png';
import round2_logo from '../../assets/images/round2.png';
import shade_circle_logo from '../../assets/images/shade-circle.png';
import { Link } from 'react-router-dom';
import { Plans, Advisors} from '../../components/Json';


/**
 * @dev:
 * @param {enableWallet undefined :
 * @param address} undefined :
 */
export default function Home({enableWallet, address}){


    return(<>
             <div className="page">
                <section className="page__section">
                <div className="container">
                    <div className="hero">
                    <h1 className="hero__title">
                        <span className="color-primary">The KSS Launchpad</span> is the first decentralized IDO platform
                    </h1>
                    <div className="hero__text">
                    on Binance Smart Chain network from Africa. Ideal for gaining users and believers from the African continent
                    </div>
                    <div className="grid _space-small _justify-center">
                        <div className="grid__el _size-12 hidden-sm-up">
                        <Link to="/kyc" className="button _color-primary _width-full">
                            KYC
                        </Link>
                        </div>
                        <div className="grid__el _size-12 _sm-size-auto">
                        <Link to="projects" className="button _color-primary _width-full _sm-width-auto">
                            View Projects
                        </Link>
                        </div>
                        <div className="grid__el _size-12 _sm-size-auto">
                            <a href="https://forms.gle/775S3whaFzbEqQyi9" className="button _width-full _sm-width-auto" target="_blank">
                                Apply to launch
                            </a>
                        </div>
                        <div className="grid__el _size-12 text-center">
                            <a href="https://forms.gle/W4RyprHnbhuBiBwm6" className="button _rounded _inverted _width-full _sm-width-auto" target="_blank">
                                Register for Queue Number
                            </a>
                        </div>
                    </div>
                    <div className="hero__partners-title">
                        OUR PARTNERS
                    </div>
                    <div className="grid _justify-center">
                        <div className="grid__el _size-auto">
                        <a href="https://aluna.social/" className="hero__partners-link" target="_blank">
                            <img
                            src={parners_logo}
                            alt="aluna"
                            width="122"
                            height="40"
                            />
                        </a>
                        </div>
                        <div className="grid__el _size-auto">
                        <a href="https://www.kycaid.com/" className="hero__partners-link" target="_blank">
                            <img
                            src={parners2_logo}
                            alt="kycaid"
                            width="122"
                            height="40"
                            />
                        </a>
                        </div>
                        <div className="grid__el _size-auto">
                        <a href="https://www.oction.io//" className="hero__partners-link" target="_blank">
                            <img
                            src={parners3_logo} style={{width: '100px' , height: '39px' , radius: '100%'}}
                            alt="oction"
                            />
                        </a>
                        </div>
                    </div>
                  </div>
                </div>
                <div className="hero-cover">
                    <img src={hero_logo} alt="" />
                </div>

                </section>
                <section className="page__section">
                <div className="container">
                    <div className="card">
                    <h2 className="page__section-title">
                        About <span className="color-primary">us</span>
                    </h2>
                    <div className="card__content">
                        <h2>WHAT IS KSSPAD?</h2>
                        <p>KSSPAD is a cross-chain decentralized IDO platform with an initial focus on the Binance Smart Chain Network.</p>
                        <p>Our goal is true and meaningful financial inclusion that is empowering to under-served geographies and beneficial to the global crypto community liquidity and user-base wise.</p>
                        <h2>WHY WORK WITH US?</h2>
                        <p>KSSPAD platform has the perfect solution for ensuring the best allocation distribution to participants. Today, people are spending tens of thousands of dollars to own launchpad tokens and getting less than $50 allocation or having to play a lottery.</p>
                        <p>The allocation you get on KSSPAD is fixed and guaranteed for all time, provided you qualify to participate. KSSPAD will employ a rotational or skipping system when the number of participants and expected invested amount exceeds the total reserved allocation from an IDO project to KSSPAD. This is where the Queue Number comes in!</p>
                        <p>The Queue number is assigned to all registered users on our registration form irrespective of whether they have passed KYC or not. The only requirement for being assigned a Queue number is having enough KSS in your Trust wallet to qualify for a Tier level. If an IDO project requires KYC, then only those who have passed KYC will be able to participate. If they don’t then all participants meeting a Tier level will be allowed to participate.</p>
                        <p>The minimum requirements for participation is having a tier qualifying amount of KSS and completing the marketing task.</p>
                        <p>In the case of excess number of participants for an IDO, those who participated in that IDO will be prevented from participating in the next IDO until the total number of qualified participants has had a chance or when the next IDO project has reserved a much higher dollar allocation for KSSPAD platform.</p>
                    </div>
                    <img src={about_logo} className="card__image" alt="" />
                    </div>
                </div>
                </section>
                <section className="page__section" style={{position: 'relative'}}>
                <div className="container">
                    <h2 className="page__section-title">
                        THE KSSPAD <span className="color-primary">TIERED SYSTEM</span>
                    </h2>
                    <div className="page__section-text">
                        The KSSPAD is the first decentralized IDO platform from Africa.
                    </div>
                    <h2 className="page__section-title">
                        ROUND 1 - <span className="color-primary">KROSHING ROUND</span>
                    </h2>
                    <div className="page__section-text">
                        The first round is called the “Kroshing Round”, where users have at least 12 hours to purchase or “Krosh” (crush) the max guaranteed amount allocated to them based on their tier.
                    </div>
                    <div className="grid">
                        <Plans />
                    </div>
                </div>
                <div className="cover">
                    <img src={cover_logo} alt="" />
                </div>
                </section>
                <section className="page__section" style={{position: 'relative'}}>
                <div className="container">
                    <div className="card">
                    <h2 className="page__section-title">
                        ROUND 2 - <span className="color-primary">First Come, First Served Round</span>
                    </h2>
                    <div className="card__content">
                        <p>If there are any unsold tokens, the opportunity will be opened to all participants to re-invest up to their maximum allowed amount or in the case of a rotation event, participants who were disallowed from participating will be allowed to participate in this case.</p>
                    </div>
                    <img src={round2_logo} className="card__image" alt="" />
                    </div>
                </div>
                <div className="circle-cover" style={{left: '-200px'}}>
                    <img src={circle_logo} alt="" />
                </div>
                </section>
                <section className="page__section">
                <div className="container">
                    <h2 className="page__section-title">
                    ADVISORS
                    </h2>
                    <div className="page__section-text">
                    Our Mentors are a great part of our team
                    </div>
                    <div className="grid _justify-center">


                    <div className="grid__el _size-auto">
                    <div className="advisor">
                        <div className="advisor__image" style={{width: '150px' , height: '150px' , radius: '100%'}}>
                        <img src = {advisor_logo} alt = 'Ian Chew'/>
                          </div>
                        <div className="advisor__name">
                        IAN <span className="color-primary">CHEW</span>
                        </div>
                        <hr class="solid"  color = '#c000c3' />
                        <div className="advisor__position" >
                        <a href='https://www.linkedin.com/in/ian-chew-jigsawcapital'><img src={linkedin_logo} style={{width: '30px' , height: '30px'}}></img></a>
                        </div>
                    </div>
                    </div>
                    <div className="grid__el _size-auto">
                    <div className="advisor">
                        <div className="advisor__image" style={{width: '150px' , height: '150px' , radius: '100%'}}>
                        <img src = {advisor_logo2} alt = 'Japhet Lim' />
                          </div>
                        <div className="advisor__name">
                        JAPHET <span className="color-primary">LIM</span>
                        </div>
                        <hr class="solid"  color = '#c000c3' />
                        <div className="advisor__position">
                        <a href='https://www.linkedin.com/in/japhet-lim-tech-lover-a9a107127'><img src={linkedin_logo} style={{width: '30px' , height: '30px'}}></img></a>
                        </div>
                    </div>
                    </div>
                    <div className="grid__el _size-auto">
                    <div className="advisor">
                        <div className="advisor__image" style={{width: '150px' , height: '150px' , radius: '100%'}}>
                        <img src = {advisor_logo3} alt = 'Nicholas soong' />
                          </div>
                        <div className="advisor__name">
                        NICHOLAS <span className="color-primary">SOONG</span>
                        </div>
                        <hr class="solid"  color = '#c000c3' />
                        <div className="advisor__position" >
                        <a href='https://www.linkedin.com/in/nicholassoong'><img src={linkedin_logo} style={{width: '30px' , height: '30px'}}></img></a>

                        </div>
                    </div>
                    </div>


                    </div>
                </div>
                </section>
                <section className="page__section" style={{position: 'relative'}}>
                <div className="circle-cover" style={{right: '-200px'}}>
                    <img src={shade_circle_logo} alt="" />
                </div>
                <div className="cover">
                    <img src={cover_logo} alt="" />
                </div>
                </section>
            </div>
    </>)
}
