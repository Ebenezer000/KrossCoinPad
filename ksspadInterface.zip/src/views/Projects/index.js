import React, {useEffect, useState} from 'react';
import arrow_left_logo from '../../assets/icons/angle-left.svg';
import arrow_right_logo from '../../assets/icons/angle-right.svg';
import project_hero_logo from '../../assets/images/projects-hero.png';
import { OpenProjects, SoonProjects } from '../../components/Json';
import common from '../../data/common.json';
import telegram_logo from '../../assets/icons/telegram.svg';
import egoras_logo from '../../assets/icons/egoras-logo.png';
import kss_logo from '../../assets/icons/ksslogo.jpeg';
import linkedin_logo from  '../../assets/icons/weblogo.png'


export default function Projects({address, provider, providers}){



    return(<>
            <div className="page">
                <section className="page__section">
                <div className="container">
                    <h2 className="page__section-title">
                    PROJECTS <span className="color-primary">COMING SOON</span>
                    </h2>
                    <div className="page__section-text">
                    The KSSPAD is the first Decentralized IDO Platform from Africa
                    </div>
                    <div className="carousel" data-component="Carousel" data-component-lazy >
                    <div className="carousel__container">
                        <div className="carousel__frame" data-component-ref="Carousel:frame">
                        <div className="grid _flexnowrap" >
                        <div className="grid__el _filled _size-12 _md-size-6 carousel__item"  data-component-ref="Carousel:item">
                            <div className="project">
                                <div className="project__main">
                                <div className="project__image">
                                    <div style={{width: '85px', height: '85px', background: '#ccc'}}><img src={kss_logo}></img></div>
                                </div>
                                <div className="project__content">
                                    <div className="project__content-header">
                                    <div className="project__content-main">
                                        <div className="project__name"> KSSPAD </div>
                                        <div className="project__socials">
                                        {
                                            (() => {
                                                const icon_logo =  `${process.env.PUBLIC_URL}/${arrow_left_logo}`;

                                                console.log(icon_logo)
                                                return (
                                                    <div className="project__social" >
                                                        <Link to="https://www.ksspad.com" className="project__social-link">

                                                            <img src={arrow_left_logo} className="project__social-icon"/>
                                                        </Link>
                                                        </div>
                                                )
                                            })
                                        }
                                        </div>
                                    </div>
                                    <div className="project__content-labels">
                                        <div className="project__content-label _status">Open in Four days </div>
                                        <div className="project__content-label ">BUSD</div>
                                    </div>
                                    </div>
                                    <div className="project__description">First Decentralized IDO Platform on BSC from Africa</div>
                                    <a href="https://www.oction.io//" className="project__link">Learn more</a>
                                </div>
                                </div>
                                <div className="project__footer">
                                <div className="project__params">
                                    <div className="project__param">
                                    <div className="project__param-label">Swap Rate</div>
                                    <div className="project__param-value">1 BUSD = 1 KSS</div>
                                    </div>
                                    <div className="project__param">
                                    <div className="project__param-label">Open Date</div>
                                    <div className="project__param-value">15th May</div>
                                    </div>
                                    <div className="project__param">
                                    <div className="project__param-label">Cap</div>
                                    <div className="project__param-value">$500,000</div>
                                    </div>
                                    <div className="project__param">
                                    <div className="project__param-label">Access</div>
                                    <div className="project__param-value">Private</div>
                                    </div>
                                </div>
                                <div className="grid">
                                    <div className="grid__el project__text">
                                        Progress
                                    </div>
                                </div>
                                <div className="project__progress">
                                    <div className="project__progress-line" style={{width: 7}}></div>
                                    </div>
                                    <div className="project__text _big">
                                        { 0 }.00%
                                    </div>
                                </div>
                            </div>
                          </div>

                          <div className="grid__el _filled _size-12 _md-size-6 carousel__item"  data-component-ref="Carousel:item">
                              <div className="project">
                                  <div className="project__main">
                                  <div className="project__image">
                                      <div style={{width: '85px', height: '85px', background: '#ccc'}}><img src={egoras_logo}></img></div>
                                  </div>
                                  <div className="project__content">
                                      <div className="project__content-header">
                                      <div className="project__content-main">
                                          <div className="project__name"> EGORAS </div>
                                          <div className="project__socials">
                                          {
                                              (() => {
                                                  const icon_logo =  `${process.env.PUBLIC_URL}/${arrow_left_logo}`;

                                                  console.log(icon_logo)
                                                  return (
                                                      <div className="project__social" >
                                                          <Link to="https://www.oction.io//" className="project__social-link">

                                                              <img src={arrow_left_logo} className="project__social-icon"/>
                                                          </Link>
                                                          </div>
                                                  )
                                              })
                                          }
                                          </div>
                                      </div>
                                      <div className="project__content-labels">
                                          <div className="project__content-label _status">Open in TBA </div>
                                          <div className="project__content-label ">BUSD</div>
                                      </div>
                                      </div>
                                      <div className="project__description">First Decentralized Microfinance protocol on BSC</div>
                                      <a href='https://egoras.com'><img src={linkedin_logo} style={{width: '20px' , height: '20px'}}></img></a>
                                      <a href='https://t.me/egorasmarket'><img src={telegram_logo} style={{margin: '5px', width: '20px' , height: '20px'}}></img></a>
                                  </div>
                                  </div>
                                  <div className="project__footer">
                                  <div className="project__params">
                                    <div className="project__param">
                                    <div className="project__param-label">Swap Rate</div>
                                    <div className="project__param-value">TBA</div>
                                    </div>
                                    <div className="project__param">
                                    <div className="project__param-label">Open Date</div>
                                    <div className="project__param-value">TBA</div>
                                    </div>
                                    <div className="project__param">
                                    <div className="project__param-label">Cap</div>
                                    <div className="project__param-value">TBA</div>
                                    </div>
                                    <div className="project__param">
                                    <div className="project__param-label">Access</div>
                                    <div className="project__param-value">Private</div>
                                    </div>
                                    </div>
                                  <div className="grid">
                                      <div className="grid__el project__text">
                                          Progress
                                      </div>
                                  </div>
                                  <div className="project__progress">
                                      <div className="project__progress-line" style={{width: 7}}></div>
                                      </div>
                                      <div className="project__text _big">
                                          { 0 }.00%
                                      </div>
                                  </div>
                              </div>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                <div className="hero-cover">
                    <img src={project_hero_logo} alt="" />
                </div>
                </section>
                <section className="page__section">
                <div className="container">
                    <h2 className="page__section-title">
                    PROJECTS <span className="color-primary">OPEN NOW</span>
                    </h2>
                    <div className="page__section-text">
                    The KSSPAD is the first Decentralized IDO Platform from Africa
                    </div>
                    <div className="text-base text-center">
                        No projects currently running
                    </div>
                    {/* <div className="carousel" data-component="Carousel" data-component-lazy>
                    <div className="carousel__container">
                        <div className="carousel__frame" data-component-ref="Carousel:frame">
                        <div className="grid _nowrap">
                            <OpenProjects />
                        </div>
                        </div>
                        <div className="carousel__buttons">
                        <div className="carousel__buttons-item _prev">
                            <button type="button" className="carousel__button" data-component-ref="Carousel:prev">
                            <icon src={arrow_left_logo}></icon>
                            </button>
                        </div>
                        <div className="carousel__buttons-item _next">
                            <button type="button" className="carousel__button" data-component-ref="Carousel:next">
                            <icon src={arrow_right_logo}></icon>
                            </button>
                        </div>
                        </div>
                    </div>
                    </div> */}
                </div>
                </section>
            </div>
        </>)
}
