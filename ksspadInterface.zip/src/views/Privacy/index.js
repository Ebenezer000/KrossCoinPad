import React from 'react';
import hero_logo from '../../assets/images/hero.png';

export default function Privacy() {
  return (
    <div className="page">
      <section className="page__section">
        <div className="container">
        <div class="wysiwyg">
          <h1>PRIVACY <span class="color-primary">POLICY</span></h1>
          <p>This Privacy Policy (“Policy”) outlines KSSPAD’s (“KSSPAD”, “we”, or “us”) practices in relation to the storage, use, processing, and disclosure of personal data that you have chosen to share with us when you access the KSSPAD Platform (as defined in the terms) or use the Services (as defined in the Terms). This Policy, together with our Terms, applies to your use of the Platform.</p>
          <br/><p>At KSSPAD, we are committed to protecting your personal data and respecting your privacy. Please read this Policy carefully to understand our practices regarding your personal data and how we will treat it. The Policy sets out the basis on which any personal data that we collect from you, or that you provide to us, will be processed by us.</p>
          <br/><p>Unless defined in this Policy, capitalised words shall have the same meaning ascribed to them in our Terms and Conditions, available above (“Terms”). Please read this Policy in consonance with our Terms.</p>
          <p>By accessing the Platform, you consent to the collection, storage, use, and disclosure of your personal data, in accordance with, and are agreeing to be bound by this Policy. We will not collect any information from you, except where it is knowingly and explicitly provided by you.</p>
          <h2>1. THE DATA WE COLLECT ABOUT YOU</h2>
          <p>a.	We may collect, use, store, and transfer different kinds of personal data about you in connection with your use of the Services, including but not limited to:</p>
          <p>I.	transaction data including purchases of crypto assets;</p>
          <p>II.	technical data including IP address, time zone setting and locations, operating system, and other technologies on your device used to access the Platform;</p>
          <p>b.	You do not have to provide any personal data or information to us but in doing so, you may not be able to take advantage of all the Services we offer.</p>
          <p>c.	Your non-custodial wallet interacts with the App on the Platform, and the smart contract stores your wallet address.</p>
          <h2>2. HOW IS YOUR PERSONAL DATA COLLECTED?</h2>
          <p>We will collect and process the following data about you:</p>
          <p>a.	Information you give us: This is the information you consent to giving us about you when you use our Services or by corresponding with us (for example, by email or chat). It includes information you provide when you share data through the Platform, through other activities commonly carried out in connection with the Services, and when you report a problem with the Services. If you contact us, we will keep a record of the information shared during the correspondence.</p>
          <br/><p>b.	Information we collect about you and your device: Each time you visit our Platform, or use one of our Services, we will automatically collect personal data including technical and usage data. We may also receive certain usage data, such as your IP address and referral source.</p>
          <br/><p>c.	We also collect, use, and share aggregated data such as statistical data for any purpose. Aggregated data could be derived from your personal data but is not considered personal data under applicable laws. For example, we may aggregate your usage data to calculate the percentage of users accessing a specific feature of the Services. However, if we combine or connect aggregated data with your personal data so that it can directly or indirectly identify you, we treat the combined data as personal data which will be used in accordance with this Policy.</p>
          <h2>3. HOW WE USE YOUR PERSONAL DATA AND FOR WHAT PURPOSES</h2>
          <p>We respect data protection principles, and process personal data only for specified, explicit, and legitimate purposes for which such personal data were provided. We primarily use your personal data to enable your use of KSSPAD and supply the Services requested by you. We may also use your personal data for the purposes provided in this Policy, and the purposes listed below:</p>
          <p>a.	You understand that when you consent to providing us with your personal data, you also consent to us sharing the personal data with third parties, including the government and regulatory entities, should the need arise under law, in connection with or related to the provision of Services.</p>
          <p>b.	You are aware that any and all information pertaining to you, whether or not you directly provide it to us may be collected, compiled, and shared by us in order to render Services to you and you expressly consent to this.</p>
          <p>c.	In general, we will not disclose personal data except in accordance with the following purpose or activity:</p>
          <p>I.	to deliver Services;</p>
          <p>II.	to administer the Services including troubleshooting and system testing;</p>
          <p>III.	to monitor trends so we can improve the Services;</p>
          <p>IV.	to perform our obligations that arise out of the arrangement we are about to enter or have entered with you;</p>
          <p>V.	to enforce the terms of the arrangement we have with you or any third party;</p>
          <p>VI.	to comply with a legal or regulatory obligation.</p>
          <h2>4. TRANSFER OF PERSONAL DATA</h2>
          <p>a.	As a part of your use of and to ensure better and seamless delivery of the Services to you, the information and personal data you provide to us may be transferred to and stored at countries other than your home jurisdiction. These countries shall be subject to data laws of their respective countries. We and our service providers may transfer your information to, or store or access it in, jurisdictions that may not provide equivalent levels of data protection as your home jurisdiction. We will take steps to ensure that your personal data receives an adequate level of protection in the jurisdictions in which we process it. By using such Service, you expressly consent to this transfer, and agree and acknowledge that we will not be responsible for any additional terms and conditions, policies, and guidelines.</p>
          <p>b.	By submitting your information and personal data to us, you agree to the transfer, storage and/or processing of such information, and personal data outside the country you are based in, in the manner described above.</p>
          <h2>5. THIRD PARTY SERVICES</h2>
          <p>a.	Our Services may, from time to time, contain services provided by or links to and from the websites of our partner networks, advertisers, and affiliates (“Third Party Services”). Please note that the Third Party Services, that may be accessible through our Services have their own privacy policies. We do not accept any responsibility or liability for the policies or for any personal data that may be collected through the Third Party Services. Please check their policies before you submit any personal data to such websites or use their services.</p>
          <p>b.	Your relationship with these third parties and their services and tools is independent of your relationship with us. These third parties may allow you to permit/restrict the information that is collected. It may be in your interest to individually restrict or enable such data collections.</p>
          <p>c.	The place of processing information depends on each third-party service provider and you should check the privacy policy of each of the service providers to identify the data shared and its purpose. You will be subject to a third party’s privacy policy if you opt in to receive communications from third parties. We will not be responsible for the privacy standards and practices of third parties.</p>
          <h2>6. DATA SECURITY</h2>
          <p>a.	We implement certain reasonable security measures to protect your personal information from unauthorised access, and such security measures are in compliance with the security practices and procedures as prescribed under the applicable laws. However, you agree and acknowledge that the above-mentioned measures do not guarantee absolute protection to the personal information and by accessing the Services, you agree to assume all risks associated with disclosure of personal information arising due to breach of firewalls and secure server software.</p>
          <p>b.	We will comply with the requirements of applicable laws in the event of a data or security risk.</p>
          <h2>7. DATA RETENTION</h2>
          <p>You are aware that your personal data will continue to be stored and retained by us for a reasonable period after your use of the Services.</p>
          <h2>8. BUSINESS TRANSITIONS</h2>
          <p>You are aware that in the event we go through a business transition, such as a merger, acquisition by another organisation, or sale of all or a portion of our assets, your personal data might be among the assets transferred.</p>
          <h2>9. CHANGE IN PRIVACY POLICY</h2>
          <p>a.	We keep our Policy under regular review and may amend this Policy from time to time, at our sole discretion.</p>
          <p>b.	The terms of this Policy may change and if they do, the changes will be posted on this page and, where appropriate, notified to you on the website. The new Policy may be displayed on-screen and you may be required to read and accept the changes to continue your use of the Services.</p>
        </div>
        </div>
        <div className="hero-cover">
          <img src={hero_logo} alt="" />
        </div>
      </section>
    </div>
  )
}
