import React from 'react';
import hero_logo from '../../assets/images/hero.png';

export default function Privacy() {
  return (
    <div className="page">
      <section className="page__section">
        <div className="container">
          <h2 className="page__section-title">
            <span className="color-primary">KYC</span> is powered by <a className="link">KYCAID.COM</a>
          </h2>
          <div className="page__section-text">
            Email us at <a href="mailto:support@krosscoin.io" className="link">support@krosscoin.io</a> to get your unique kyc form link. Mention your KSS-BEP20 address and make sure to have at least 100 KSS-BEP20.
            <br/><br/>Residents of the United States of America, Tunisia, Iran, DPRK are restricted from participating in the KYC process.
            <br/><br/>Thanks.
          </div>
        </div>
        <div className="hero-cover">
          <img src={hero_logo} alt="" />
        </div>
      </section>
    </div>
  )
}
