import React from 'react';
import hero_logo from '../../assets/images/hero.png';
import help1Image from '../../assets/images/help-1.png';
import help2Image from '../../assets/images/help-2.png';
import help3Image from '../../assets/images/help-3.png';
import help4Image from '../../assets/images/help-4.png';

export default function Privacy() {
  return (
    <div className="page">
      <section className="page__section">
        <div className="container">
          <h1 className="hero__title">
            How to Set Up and Use Trust Wallet for <span className="color-primary">ksspad.com</span>
          </h1>
          <div className="wysiwyg">
            <h2>How To Set Up Your Trust Wallet for Binance Smart Chain</h2>
            <p>1. Download Trust Wallet. Update your app to make sure it is up to date if you already have it.</p>
            <p>2. Set up your trust wallet and make sure to save your seed or back up phrases. Whoever has them has your funds.</p>
            <p>3. Go to your BNB smart chain wallet and click on "Receive" to see your address.</p>
            <p>4. Now with that address you are ready to start using Binance Smart Chain.</p>
            <h2>How to Use KSSPAD in Trust Wallet</h2>
            <p>5. For iOS users, you will need to initiate the Dapp Browser. Android users already have the Dapp Browser.</p>
            <p>6. For Android Users: Open the Dapp Browser by pressing on the four squares icon at the bottom of the app.</p>
            <div className="wysiwyg__image">
              <img src={help1Image} alt="" />
            </div>
            <p>7. Enter in ksspad.com</p>
            <p>8. Ensure network is on Binance Smart Chain (check the logo at the top left)</p>
            <p>9. Enjoy the Dapp.</p>
            <h2>For iOS users</h2>
            <p>1. Open the Safari Browser and enter in this URL: trust://browser_enable , then tap GO</p>
            <div className="wysiwyg__image">
              <img src={help2Image} alt="" />
            </div>
            <p>2. You'll see a prompt saying "Trust this app?" Click Yes or Open</p>
            <div className="wysiwyg__image">
              <img src={help3Image} alt="" />
            </div>
            <p>3. The Trust Wallet will be opened and the Dapp Browser enabled.</p>
            <div className="wysiwyg__image">
              <img src={help4Image} alt="" />
            </div>
          </div>
        </div>
        <div className="hero-cover">
          <img src={hero_logo} alt="" />
        </div>
      </section>
      <section className="page__section">
          <div className="container">
              <div className="grid _justify-center">
                  <div className="grid__el _size-auto">
                      <a className="button _color-primary" href="https://exchange.pancakeswap.finance/#/swap?outputCurrency=0xa1f0efd80793f97edc74f58c0cef93f3a1b72a79" target="_blank">
                          BUY ON PANCAKESWAP
                      </a>
                  </div>
              </div>
          </div>
      </section>
    </div>
  )
}
