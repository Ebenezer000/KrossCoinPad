import React, { useEffect, useState } from 'react';
import { BrowserRouter as Switch, Route, Link } from "react-router-dom";
import Header from '../components/Header';
// import { ALLOWED_CHAIN, CHAIN } from '../constants';
import WalletConnectProvider from "@walletconnect/web3-provider";
import Web3Modal from "web3modal";
import { ethers } from "ethers";
import { INFURA_ID } from '../constants';
import ContentWrapper from '../components/ContentWrapper';
import Home from '../views/Home';
import Footer from '../components/Footer';
import { verifyChain } from '../hooks/VerifyChain';
import Projects from '../views/Projects';
import Privacy from '../views/Privacy';
import Terms from '../views/Terms';
import Wallet from '../views/Wallet';
import Kyc from '../views/Kyc';

export const Routes = () => {

    // useEffect(() => {
    //     if (web3Modal.cachedProvider) {
    //         enableWallet()
    //         // disconnect()
    //        }
    //    }, [])

       const [address, setAddress] = useState(null);
       const [chain, setChain] = useState(null);
       const [network, setNetwork] = useState(null);
       const [balance, setBalance] = useState(0);
       const [providers, setProviders] = useState(null);
       const [provider, setProvider] = useState(null);
       const [connected, isConnected] = useState(false);
       const [connector, setConnector] = useState(null);

       useEffect(() => {

            console.log('connector', connector)
       }, [connector])

        const providerOptions = {
            walletconnect: {
                package: WalletConnectProvider,
                options: {
                    infuraId: `${INFURA_ID}`,
                    rpc: {
                        56: "https://bsc-dataseed1.binance.org",
                        97: "https://data-seed-prebsc-2-s2.binance.org:8545",
                    },
                }
            },
        }

        const web3Modal = new Web3Modal({
            cacheProvider: true, // optional
            providerOptions // required
        });

        const enableWallet = async() =>{
            try {
                const providers = await web3Modal.connect();
                const provider = new ethers.providers.Web3Provider(providers, "any");
                setProviders(providers), setProvider(provider);
                subscribeProvider(providers, provider);
              } catch(e) {
                  console.log(e)
                return;
            }
        }

        const loadBlockchainData = async (provider) =>{
            try {
                const signer = provider.getSigner();
                const address = await signer.getAddress();
                const networkId = await provider.getNetwork();
                const chainId = networkId.chainId;
                const bnb = await provider.getBalance(address);
                const bnbBalance = parseFloat(ethers.utils.formatEther(bnb)).toPrecision(3);
                setAddress(address), setChain(chainId), setNetwork(networkId), setBalance(bnbBalance),
                isConnected(!connected);
                // verifyChain(chainId);
            } catch (e) {
                console.log(e);
                return;
            }
        }

        const subscribeProvider = async (providers, provider) => {
            providers.on("disconnect", () => {
                // notify("account disconnected",4)
            });
            providers.on("accountsChanged", () => {
                loadBlockchainData(provider)
            });
            provider.on("network", (newNetwork, oldNetwork) => {
                if (newNetwork) {
                    loadBlockchainData(provider)
                }
            });
            await loadBlockchainData(provider)
            await setConnector(provider.connection.url === 'eip-1193:' ? 'walletconnect' : provider.connection.url)
        }

        const disconnect = async () =>{
            if(typeof providers.close !== "undefined"){
                providers.close()
                isConnected(!connected);
            }
            await web3Modal.clearCachedProvider()
            window.location.reload()
        }


        return (
                <Switch>
                    <Header enableWallet={enableWallet}
                            address={address}
                            bnbBalance={balance}
                            chain={chain}
                            network={network}
                            disconnect={disconnect}
                            provider={provider} />

                    <ContentWrapper>
                        <Route exact path="/">
                            <Home enableWallet={enableWallet}
                                  address={address}/>
                        </Route>
                        <Route exact path="/projects">
                            <Projects address={address} />
                        </Route>
                        <Route exact path="/wallet">
                            <Wallet />
                        </Route>
                        <Route exact path="/terms-of-use">
                            <Terms />
                        </Route>
                        <Route exact path="/privacy-policy">
                            <Privacy />
                        </Route>
                        <Route exact path="/kyc">
                            <Kyc />
                        </Route>
                    </ContentWrapper>
                    <Footer />
                </Switch>
        )
}
