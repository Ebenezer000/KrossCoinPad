import React, { Suspense } from 'react';
import { BrowserRouter as Router } from "react-router-dom";
import BodyWrapper from './components/BodyWrapper';
import { ethereum } from './constants';
import { isMobile } from 'react-device-detect';
import { Routes } from './routes';

if(!isMobile && ethereum){
  ethereum.autoRefreshOnNetworkChange = false;
}

export default function App() {

  return (
    <Router>
      <Suspense fallback={null}>
        <BodyWrapper>
          <Routes darkmode={false} />
        </BodyWrapper>
      </Suspense>
    </Router>
  )
}
